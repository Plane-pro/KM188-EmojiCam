1)Please ensure you are in a location with good lighting.
2)to use the video emoji feature, please press the  :) button
	a) draw the shape of the emoji (^ v o * ->) with a pointed finger