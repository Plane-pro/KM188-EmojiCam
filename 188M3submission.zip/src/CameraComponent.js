import { useEffect, useRef } from "react";
import * as handTrack from 'handtrackjs';

let video = null;
let canvas = null;
let context = null;
let videoloaded = false;

let model = null;

// video.width = 500
// video.height = 400

const modelParams = {
  flipHorizontal: true, // flip e.g for video
  maxNumBoxes: 20, // maximum number of boxes to detect
  iouThreshold: 0.5, // ioU threshold for non-max suppression
  scoreThreshold: 0.6, // confidence threshold for predictions.
};

handTrack.load(modelParams).then((lmodel) => {
  console.log("testicle")
  // detect objects in the image.
  model = lmodel;
  console.log(model);

});


function startVideo(onDetect) {
  //video = document.getElementById("myvideo");
  canvas = document.getElementById("canvas");
  context = canvas.getContext("2d");
  handTrack.startVideo(video).then(function (status) {
    console.log("video started", status);
    if (status) {

        runDetection(onDetect);

      
    } 
    else {
      
    }
    
  });
}

// function toggleVideo() {
//   if (!isVideo) {
//     updateNote.innerText = "Starting video";
//     startVideo();
//   } else {
//     updateNote.innerText = "Stopping video";
//     handTrack.stopVideo(video);
//     isVideo = false;
//     updateNote.innerText = "Video stopped";
//   }
// }


function runDetection(onDetect) {
  console.log(onDetect)
  if(model){
    model.detect(video).then((predictions) => {
      console.log("Predictions: ", predictions);
      onDetect.current(predictions);
      model.renderPredictions(predictions, canvas, context, video);
      requestAnimationFrame(() => runDetection(onDetect));
    });
  }
  else{
    requestAnimationFrame(() => runDetection(onDetect));
  }
}


function runDetectionImage(img) {
  model.detect(img).then((predictions) => {
    console.log("Predictions: ", predictions);
    model.renderPredictions(predictions, canvas, context, img);
  });
}

// Load the model.


function CameraComponent(props){
  const onDetectref = useRef(props.onDetect);
  onDetectref.current = props.onDetect;
    useEffect(()=> {if(props.stchange === true){startVideo(onDetectref)}},[props.stchange])
    return(
        <div className="CameraComponent">
      <video className="Display" autoPlay id="myvideo" controls ref={(el) => video = el}></video>
      <canvas id="canvas" className="VideoArea"></canvas>
    </div>
    )
}

export default CameraComponent